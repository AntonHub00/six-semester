====================
Improving the plugin
====================

Most information about using Workbench Python scripting API is
available in the Scripting and Plugin Development documentation:

http://mysqlworkbench.org/learn/learn/

The documentation on GRT Globals Tree and its classes is particularly
useful:

http://mysqlworkbench.org/workbench/doc/globals/index.html
