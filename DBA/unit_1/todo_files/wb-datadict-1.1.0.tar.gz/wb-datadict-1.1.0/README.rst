=================
WB Datadict 1.1.0
=================


.. figure:: https://multimedialib.files.wordpress.com/2014/09/wb-datadict-2014-09-14.png
   :alt: Figure 1. Plugin location in MySQL Workbench.
   :align: center

A plugin for MySQL Workbench Community Edition 6.x. This plugin allows
you to generate an HTML data dictionary from a selected schema.


Documentation
=============

* `English`_
* `Español`_


Copying
=======

Public domain 2011 `sirgazil`_. All rights waived.



.. REFERENCES
.. _English: http://sirgazil.bitbucket.org/en/doc/wb-datadict/1.1.0/manual/
.. _Español: http://sirgazil.bitbucket.org/es/doc/wb-datadict/1.1.0/manual/
.. _sirgazil: http://sirgazil.bitbucket.org/
